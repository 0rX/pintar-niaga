<?php $__env->startSection('content'); ?>

<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<div class="container" data-bs-theme="light">
    <div class="row justify-content-center">
        <div class="col-md-11">
            <div data-bs-theme="light" class="card border-1 mb-4" style="max-height: 600px;">
                <div class="card-header d-flex fw-bold">
                    <div class="me-auto">
                        <?php echo e($title); ?>

                    </div>
                    <div class="ms-auto">
                        <button type="button" data-bs-toggle="modal"
                            data-bs-target="#addAccModal"
                            class="btn btn btn-primary text-white d-flex align-items-center gap-2">
                            <i class='bx bx-plus-circle fs-4'></i> New Item
                        </button>
                    </div>
                </div>
                <div class="modal fade" id="addAccModal" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h1 class="modal-title fs-5">Create Item</h1>
                                <button type="button" class="btn btn-danger px-1 py-0 my-0" data-bs-dismiss="modal"
                                    aria-label="Close"><i class='bx bx-x fs-3 pt-1'></i></button>
                            </div>
                            <div class="modal-body">
                                <form enctype="multipart/form-data" action="<?php echo e(route('inventory-index.store')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="mb-5">
                                        <label for="cp_index" class="ms-2">Company Index</label>
                                        <input type="text" value="<?php echo e($cp_index); ?>" name="cp_index" id="cp_index" class="form-control mb-3 fs-5" readonly>
                                        <label for="name" class="ms-2">Item Name</label>
                                        <input type="text" name="name" id="name" class="form-control mb-3 fs-5" required>
                                        <label for="purchase_price" class="ms-2">Purchase Price</label>
                                        <input type="number" name="purchase_price" id="purchase_price" class="form-control mb-3 fs-5" required>
                                        <label for="stock" class="ms-2">Stock</label>
                                        <input type="number" name="stock" id="stock" class="form-control mb-3 fs-5" required>
                                        <label for="amount_unit" class="ms-2">Measure Unit</label>
                                        <input type="text" name="amount_unit" id="amount_unit" class="form-control mb-3 fs-5" required>
                                        <label for="image" class="ms-2">Image</label>
                                        <input type="file" name="image" id="image" accept="image/.jpg, image/.png, image/.jpeg" class="form-control mb-3 fs-5" required>
                                        <label for="description" class="ms-2">Description</label>
                                        <textarea name="description" id="description" class="form-control mb-3 fs-5" row="3" style="resize:none;"></textarea>
                                    </div>
                                    <div class="d-flex my-3 align-items-center justify-content-center gap-2">
                                        <button class="btn btn-primary" type="submit">
                                            Create
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-body card-data-table custom-scrollbar-2">
                    <?php if($ingredients->count() > 0): ?>
                        <?php
                            $cp_index += 1;
                        ?>
                        <div class="table">
                            <table class="table table-striped align-middle table-primary">
                                <thead>
                                    <tr>
                                        <th class="text-center" scope="col">No</th>
                                        <th class="text-start" scope="col">Picture</th>
                                        <th class="text-start" scope="col">Name</th>
                                        <th class="text-start" scope="col">Stock</th>
                                        <th class="text-center" scope="col">Price</th>
                                        <th class="text-start" scope="col">Description</th>
                                        <th class="text-center" scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody >
                                    <?php $__currentLoopData = $ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="text-center align-self-middle"><?php echo e(++$key); ?></td>
                                            <td style="max-width: 100px;">
                                                <?php
                                                    $imagepath = 'storage/images/'.$ingredient->image;
                                                ?>
                                                <img src="<?php echo e(url($imagepath)); ?>" alt="<?php echo e($ingredient->name); ?>" width="90px" class="img-fluid">
                                            </td>
                                            <?php
                                                $ig_index = $ingredients->pluck('name')->search($ingredient->name) + 1;
                                            ?>
                                            <td style="max-width: 100px;">
                                                <a href="/manage/<?php echo e($cp_index); ?>/inventory/<?php echo e($ig_index); ?>/">
                                                    <?php echo e($ingredient->name); ?>

                                                </a>
                                            </td>
                                            <td style="max-width: 100px;"><?php echo e(number_format($ingredient->stock)); ?> <?php echo e($ingredient->amount_unit); ?></td>
                                            <td class="text-center" style="max-width: 100px;">Rp. <?php echo e(number_format((int)$ingredient->purchase_price)); ?></td>
                                            <td style="max-width: 150px;"><?php echo e($ingredient->description); ?></td>
                                            <td>
                                                <div class="d-flex align-items-center justify-content-center gap-2">
                                                    <button type="button" data-bs-toggle="modal"
                                                        data-bs-target="#addModal<?php echo e($ingredient->ingredient_id); ?>"
                                                        class="btn btn-sm btn-primary text-white d-flex align-items-center gap-2">
                                                        <i class='bx bx-edit'></i> Edit
                                                    </button>
                                                    
                                                    <form action="<?php echo e(route('inventory-index.destroy', $ingredient->ingredient_id)); ?>" method="post"
                                                        class="d-inline">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit"
                                                            class="btn btn-danger btn-sm d-flex align-items-center gap-2 py-2"
                                                            onclick="return confirm('Delete <?php echo e($ingredient->name); ?> ?')">
                                                            <i class='bx bxs-trash' ></i>
                                                        </button>
                                                    </form>
                                                    
                                                </div>
                                            </td>
                                        </tr>
                                        <div class="modal fade" id="addModal<?php echo e($ingredient->ingredient_id); ?>" tabindex="-1"
                                            aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h1 class="modal-title fs-5">Edit <?php echo e($ingredient->name); ?></h1>
                                                        <button type="button" class="btn btn-danger px-1 py-0 my-0" data-bs-dismiss="modal"
                                                            aria-label="Close"><i class='bx bx-x fs-3 pt-1'></i></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form enctype="multipart/form-data" action="<?php echo e(route('inventory-index.update', $ingredient->ingredient_id)); ?>"
                                                            method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('PUT'); ?>
                                                            <div class="mb-5">
                                                                <label for="name" class="ms-2">Item Name</label>
                                                                <input value="<?php echo e($ingredient->name); ?>" type="text" name="name" id="name" class="form-control mb-3 fs-5" required>
                                                                <label for="stock" class="ms-2">Stock</label>
                                                                <input value="<?php echo e($ingredient->stock); ?>" type="number" name="stock" id="stock" class="form-control mb-3 fs-5" required>
                                                                <label for="amount_unit" class="ms-2">Measure Unit</label>
                                                                <input value="<?php echo e($ingredient->amount_unit); ?>" type="text" name="amount_unit" id="amount_unit" class="form-control mb-3 fs-5" required>
                                                                <label for="purchase_price" class="ms-2">Purchase Price</label>
                                                                <input value="<?php echo e($ingredient->purchase_price); ?>" type="number" name="purchase_price" id="purchase_price" class="form-control mb-3 fs-5" required>
                                                                <label for="image" class="ms-2">Image</label>
                                                                <input type="file" name="image" id="image" accept="image/.jpg, image/.png, image/.jpeg" class="form-control mb-3 fs-5">
                                                                <label for="description" class="ms-2">Description</label>
                                                                <textarea name="description" id="description" class="form-control mb-3 fs-5" row="3" style="resize:none;"><?php echo e($ingredient->description); ?></textarea>
                                                            </div>
                                                            <button class="btn btn-primary px-4" type="submit">
                                                                Save Changes
                                                            </button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p class="mb-0 text-danger text-center">Nothing here</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/baskoro/project/laravel-projects/pintar-niaga/resources/views/company/inventory/index.blade.php ENDPATH**/ ?>