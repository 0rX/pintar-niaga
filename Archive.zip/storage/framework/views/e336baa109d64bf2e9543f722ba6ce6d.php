<div class="sidebar">
    <div class="logo-details">
        <i class='bx bxs-color side-toggle'></i>
        <span class="logo_name fst-italic"><?php echo e(__('Pintar Niaga')); ?></span>
        <i class='bx bx-chevrons-left side-toggle menu-arrow mx-4'></i>
    </div>
    <ul class="nav-link">
        <li>
            <?php
                $currentRoute = Request::url();
                ##dd($currentRoute);
                $uris = explode('/', $currentRoute);
                ##dd($uris);
                $cp_dashboard = "/".$uris[3]."/".$uris[4]."/";
                $ac_dashboard = "/".$uris[3]."/".$uris[4]."/accounts/";
                $ct_dashboard = "/".$uris[3]."/".$uris[4]."/categories/";
                $pd_dashboard = "/".$uris[3]."/".$uris[4]."/products/";
                ##dd($cp_dashboard);
            ?>
            <a href="<?php echo e($cp_dashboard); ?>">
                <i class="bx bx-grid-alt"></i>
                <span class="link_name">Dashboard</span>
            </a>
            <ul class="sub-menu blank">
                <li>
                    <a class="link_name" href="<?php echo e($cp_dashboard); ?>">Company Dashboard</a>
                </li>
            </ul>
        </li>
        <li>
            <div class="icon-link">
                <a href="<?php echo e($ac_dashboard); ?>">
                    <i class='bx bxs-bank' ></i>
                    <span class="link_name">Accounts</span>
                </a>
                <i class="bx bxs-chevron-down arrow"></i>
            </div>
            <ul class="sub-menu">
                <li>
                    <a class="link_name" href="<?php echo e($ac_dashboard); ?>">Accounts</a>
                </li>
                <li>
                    <a href="#">Cash In</a>
                </li>
                <li>
                    <a href="#">Payment</a>
                </li>
                <li>
                    <a href="#">Reconciliation</a>
                </li>
            </ul>
        </li>
        <li>
            <a href="<?php echo e($ct_dashboard); ?>">
                <i class='bx bx-purchase-tag-alt' ></i>
                <span class="link_name">Categories</span>
            </a>
            <ul class="sub-menu blank">
                <li>
                    <a class="link_name" href="<?php echo e($ct_dashboard); ?>">Categories</a>
                </li>
            </ul>
        </li>
        <li>
            <div class="icon-link">
                <a href="<?php echo e($pd_dashboard); ?>">
                    <i class="bx bx-basket"></i>
                    <span class="link_name">Products</span>
                </a>
                <i class="bx bxs-chevron-down arrow"></i>
            </div>
            <ul class="sub-menu">
                <li>
                    <a class="link_name" href="<?php echo e($pd_dashboard); ?>">Products</a>
                </li>
                <li>
                    <a href="#">Inventory</a>
                </li>
                <li>
                    <a href="#">Move Stock</a>
                </li>
            </ul>
        </li>
        <li>
            <div class="icon-link">
                <a href="#">
                    <i class='bx bx-package' ></i>
                    <span class="link_name">Purchase</span>
                </a>
                <i class="bx bxs-chevron-down arrow"></i>
            </div>
            <ul class="sub-menu">
                <li>
                    <a class="link_name" href="#">Purchase</a>
                </li>
                <li>
                    <a href="#">Purchase history</a>
                </li>
            </ul>
        </li>
        <li>
            <div class="icon-link">
                <a href="#">
                    <i class='bx bxs-cart' ></i>
                    <span class="link_name">Sale</span>
                </a>
                <i class="bx bxs-chevron-down arrow"></i>
            </div>
            <ul class="sub-menu">
                <li>
                    <a class="link_name" href="#">Sale</a>
                </li>
                <li>
                    <a href="#">Sale History</a>
                </li>
            </ul>
        </li>
        <li>
            <a href="#">
                <i class="bx bx-cog"></i>
                <span class="link_name">Settings</span>
            </a>
            <ul class="sub-menu blank">
                <li>
                    <a class="link_name" href="#">Settings</a>
                </li>
            </ul>
        </li>
        <li>
            <a href="/index">
                <i class="bx bx-door-open"></i>
                <span class="link_name">Return</span>
            </a>
            <ul class="sub-menu blank">
                <li>
                    <a class="link_name" href="/index">Return Home</a>
                </li>
            </ul>
        </li>
    </ul>
</div>
<?php /**PATH /Users/baskoro/project/laravel-projects/vegasfinance/resources/views/components/component/company/sidenav.blade.php ENDPATH**/ ?>