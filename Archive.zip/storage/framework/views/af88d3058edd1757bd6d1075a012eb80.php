<style>
    /** Custom CSS Styles here */
</style>

<nav class="navbar navbar-expand-md">
    <div class="container-fluid px-4">
        <a class="d-flex navbar-brand text-secondary fs-2 fw-bolder fst-italic" href="<?php echo e(url('/')); ?>">
            <img class="align-self-center px-1" style="width: 60px;" src="/storage/assets/logo/logo-blank-bg-1.svg" alt="Home">
            <div class="align-self-center px-1">
                <span id="logo-nav-start">Pintar</span>
                <span id="logo-nav-end">NIAGA</span>
            </div>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <!-- Left Side Of Navbar -->
            <?php if(auth()->guard()->check()): ?>
                    <ul class="navbar-nav me-auto fst-italic fs-4">
                        <li class="nav-item">
                            <a class="nav-link left-menu py-auto mt-1 <?php echo e((request()->is('index')) ? 'active' : ''); ?>" href="<?php echo e(url('/index')); ?>">Dashboard</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link left-menu py-auto mt-1 <?php echo e((request()->is('management/employee*')) ? 'active' : ''); ?>" href="<?php echo e(url('/management/employee')); ?>">Employee</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link left-menu py-auto mt-1 <?php echo e((request()->is('management/reports*')) ? 'active' : ''); ?>" href="<?php echo e(url('/management')); ?>">Reports</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link left-menu py-auto mt-1 <?php echo e((request()->is('management/task*')) ? 'active' : ''); ?>" href="<?php echo e(url('/management')); ?>">Task</a>
                        </li>
                    </ul>
            <?php else: ?>
                <ul class="navbar-nav me-auto fst-italic fw-bolder fs-4">
                    <li class="nav-item">
                        <a class="nav-link left-menu py-auto mt-1" href="<?php echo e(url('/')); ?>">About</a>
                    </li>
                </ul>
            <?php endif; ?>
            <!-- Right Side Of Navbar -->
            <ul class="navbar-nav ms-auto">
                <!-- Authentication Links -->
                <?php
                    $disabledCanvas = ['register','password/reset','login']
                ?>

                <?php if(auth()->guard()->guest()): ?>
                    <?php if (! (in_array(Route::getCurrentRoute()->uri, $disabledCanvas))): ?>
                    <li class="nav-item">
                        <a class="nav-link fs-5 py-auto" data-bs-toggle="offcanvas" role="button" aria-controls="offcanvaslogin" data-bs-target="#offcanvaslogin"><?php echo e(__('Login')); ?></a>
                    </li>
                    <?php elseif(Route::getCurrentRoute()->uri === 'login'): ?>
                        <li class="nav-item">
                            <a class="nav-link fs-5 py-auto" href="<?php echo e(url('register')); ?>"><?php echo e(__('Register')); ?></a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link fs-5 py-auto" href="<?php echo e(url('login')); ?>"><?php echo e(__('Login')); ?></a>
                        </li>
                    <?php endif; ?>
                <?php else: ?>
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            
                            <?php echo e(Auth::user()->name); ?>

                        </a>

                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                            <a href="<?php echo e(route('profile')); ?>" class="dropdown-item">
                                <?php echo e(__('Profile')); ?>

                            </a>
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();
                                                document.getElementById('logout-form').submit();">
                                <?php echo e(__('Logout')); ?>

                            </a>

                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav><?php /**PATH /Users/baskoro/project/laravel-projects/vegasfinance/resources/views/layouts/navigation/top.blade.php ENDPATH**/ ?>