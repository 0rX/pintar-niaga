<style>
    /** Custom CSS Styles here */
</style>

<nav class="navbar navbar-expand-md navbar-dark bg-dark shadow-sm">
    <div class="container">
        <a class="navbar-brand text-secondary fs-1 fw-bolder fst-italic" href="<?php echo e(url('/')); ?>">
            <?php echo e(config('app.name', 'Laravel')); ?>

        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <!-- Left Side Of Navbar -->
            <ul class="navbar-nav me-auto">

            </ul>
            <!-- Right Side Of Navbar -->
            <ul class="navbar-nav ms-auto border border-dark">
                <!-- Authentication Links -->
                <?php
                    $disabledCanvas = ['register','password/reset','']
                ?>

                <?php if(auth()->guard()->guest()): ?>
                    <?php if (! (in_array(Route::getCurrentRoute()->uri, $disabledCanvas))): ?>
                        <li class="nav-item">
                            <a class="nav-link fs-5 py-auto" data-bs-toggle="offcanvas" role="button" aria-controls="offcanvasExample" href="#offcanvasExample"><?php echo e(__('Login')); ?></a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link fs-5 py-auto" href="<?php echo e(url('/login')); ?>"><?php echo e(__('Login')); ?></a>
                        </li>
                    <?php endif; ?>
                <?php else: ?>
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            <?php echo e(Auth::user()->name); ?>

                        </a>

                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();
                                                document.getElementById('logout-form').submit();">
                                <?php echo e(__('Keluar Bro')); ?>

                            </a>

                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav><?php /**PATH /Users/baskoro/project/laravel-projects/vegasfinance/resources/views/layouts/navigation/member.blade.php ENDPATH**/ ?>