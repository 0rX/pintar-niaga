<?php $__env->startSection('content'); ?>

<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<div class="container" data-bs-theme="light">
    <div class="row justify-content-center">
        <div class="col-md-11">
            <div data-bs-theme="light" class="card border-1 mb-4" style="max-height: 800px;">
                <div class="card-body">
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <?php if($product->image): ?>
                                <img src="<?php echo e($product->image); ?>" class="card-img-top" alt="<?php echo e($product->name); ?>">
                            <?php endif; ?>
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e($product->name); ?></h5>
                                <p class="card-text">Category: <?php echo e($product->category->name); ?></p>
                                <p class="card-text">Stock: <?php echo e($product->stock); ?></p>
                                <p class="card-text">Purchase Price: <?php echo e($product->purchase_price); ?></p>
                                <p class="card-text">Sale Price: <?php echo e($product->sale_price); ?></p>
                                <p class="card-text"><?php echo e($product->description); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/baskoro/project/laravel-projects/vegasfinance/resources/views/company/products/overview.blade.php ENDPATH**/ ?>