<?php $__env->startSection('content'); ?>

<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<div class="container" data-bs-theme="light">
    <div class="row justify-content-center">
        <div class="col-md-11">
            <div class="row justify-content-end px-4 fs-2">
                <div class="fw-bold">
                    Category <?php echo e($category->name); ?>

                </div>
            </div>
            <div data-bs-theme="light" class="card border-1 mb-4" style="max-height: 500px;">
                <div class="card-body card-data-table">
                    <?php if($products->count() > 0): ?>
                        <div class="table">
                            <table class="table table-success table-striped align-middle">
                                <thead>
                                    <tr>
                                        <th class="text-center" style="max-width: 15px;" scope="col">No</th>
                                        <th class="text-start" style="max-width: 75px;" scope="col">Picture</th>
                                        <th class="text-start" style="max-width: 40px;" scope="col">Product</th>
                                        <th class="text-center" style="max-width: 100px;" scope="col">Sell Price</th>
                                        <th class="text-start" style="max-width: 100px;" scope="col">Description</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="text-center"><?php echo e(++$key); ?></td>
                                            <td class="text-start" style="max-width: 100px;">
                                                <?php
                                                    $imagepath = 'storage/images/'.$product->image;
                                                ?>
                                                <img src="<?php echo e(url($imagepath)); ?>" alt="<?php echo e($product->name); ?>" width="90px" class="img-fluid">
                                            </td>
                                            <td class="text-start" style="max-width: 40px;"><?php echo e($product->name); ?></td>
                                            <td class="text-center" style="max-width: 100px;"><?php echo e($product->sale_price); ?></td>
                                            <td class="text-start" style="max-width: 100px;"><?php echo e($product->description); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p class="mb-0 text-center">Nothing here</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/baskoro/project/laravel-projects/pintar-niaga/resources/views/company/categories/overview.blade.php ENDPATH**/ ?>