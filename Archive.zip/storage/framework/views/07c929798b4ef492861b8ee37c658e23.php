<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /Users/baskoro/project/laravel-projects/vegasfinance/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>