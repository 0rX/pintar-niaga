<?php $__env->startSection('content'); ?>
<?php if(auth()->guard()->guest()): ?>
    <?php echo $__env->make('layouts.navigation.offcanvaslogin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php $__env->startSection('title'); ?>
    Welcome
<?php $__env->stopSection(); ?>

<div class="welcome">
    <div class="content-track d-flex flex-row">
        <div id="splitter-1" class="splitter">
            <img class="wc-logo-frame" src="storage/assets/logo/logo-blank-bg-1-frame.svg" alt="">
            <img class="wc-logo-accent" src="storage/assets/logo/logo-blank-bg-1-accent.svg" alt="">
            <div class="masking"></div>
        </div>
    </div>
</div>

<?php if(Session::has('flareOCV')): ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            let offcanvasElement = document.querySelector('#offcanvaslogin');
            let bootstrapOffcanvas = new bootstrap.Offcanvas(offcanvasElement);
            bootstrapOffcanvas.show();
            
            // Remove the showOffcanvas flag from the session
            fetch('/remove-ocv-flag')
                .then(response => response.json())
                .then(data => console.log(data))
                .catch(error => console.error(error));

        });
    </script>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/baskoro/project/laravel-projects/vegasfinance/resources/views/welcome.blade.php ENDPATH**/ ?>