<?php $__env->startSection('content'); ?>

<?php $__env->startSection('title'); ?>
    Managing Employees
<?php $__env->stopSection(); ?>

<div class="container d-flex flex-column">
    <div data-bs-theme="light" class="card border-1 mb-4" style="max-height: 200px;">
        <div class="card-header d-flex fw-bold">
            <div class="me-auto">
                <?php echo e(__('Staff Positions')); ?>

            </div>
            <div class="ms-auto">
                <button type="button" data-bs-toggle="modal"
                    data-bs-target="#addCompModal"
                    class="btn btn-sm btn-primary text-white d-flex align-items-center gap-2">
                    <i class='bx bx-edit'></i> New
                </button>
            </div>
        </div>
        <div class="modal fade" id="addPosModal" tabindex="-1"
            aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5">Create Position</h1>
                        <button type="button" class="btn btn-danger" data-bs-dismiss="modal"
                            aria-label="Close">x</button>
                    </div>
                    <div class="modal-body">
                        <form action="<?php echo e(route('index')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="name">Position Name</label>
                                <input type="text" name="name" id="name" class="form-control" required>
                                <label for="name">Position Description</label>
                                <input type="text" name="description" id="description" class="form-control" required>
                            </div>
                            <button class="btn btn-primary px-4" type="submit">
                                Create
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-body card-data-table">
            <?php if($positions->count() > 0): ?>
                <div class="table">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th class="text-start" scope="col">No</th>
                                <th class="text-start" scope="col">Position</th>
                                <th class="text-center" scope="col">Assigned</th>
                                <th class="text-start" scope="col">Description</th>
                                <th class="text-center" scope="col"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(++$key); ?></td>
                                    <td><?php echo e($position->name); ?></td>
                                    <?php if($position->count() > 0): ?>
                                        <td class="text-center"><?php echo e(number_format($position->count())); ?> orang</td>
                                    <?php else: ?>
                                        <td class="text-center">Vacant</td>
                                    <?php endif; ?>
                                    <td><?php echo e($position->description); ?></td>
                                    <td>
                                        <div class="d-flex align-items-center justify-content-end gap-2">
                                            <?php if($position->id > 1): ?>
                                                <form action="<?php echo e(route('index', "pos-".$position->id)); ?>" method="post"
                                                    class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit"
                                                        class="btn btn-danger btn-sm d-flex align-items-center gap-2"
                                                        onclick="return confirm('Delete <?php echo e($position->name); ?> position?')">
                                                        <i class="bx bx-trash-alt"></i> Remove
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                            <button type="button" data-bs-toggle="modal"
                                                data-bs-target="#addModal<?php echo e($position->id); ?>"
                                                class="btn btn-sm btn-primary text-white d-flex align-items-center gap-2">
                                                <i class='bx bx-edit'></i> Edit
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <div class="modal fade" id="addModal<?php echo e($position->id); ?>" tabindex="-1"
                                    aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h1 class="modal-title fs-5">Edit Position <?php echo e($position->name); ?></h1>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <form action="<?php echo e(route('index', 'pos-'.$position->id)); ?>"
                                                    method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PUT'); ?>
                                                    <div class="mb-3">
                                                        <label for="name">Position Name</label>
                                                        <input type="text" name="name" id="name"
                                                            value="<?php echo e($position->name); ?>" class="form-control"
                                                            required>
                                                        <label for="name">Position Description</label>
                                                        <input type="text" name="description" id="description"
                                                            value="<?php echo e($position->description); ?>" class="form-control"
                                                            required>
                                                    </div>
                                                    <button class="btn btn-primary px-4" type="submit">
                                                        Save Changes
                                                    </button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="mb-0 text-danger text-center">Belum ada Posisi Staff</p>
            <?php endif; ?>
        </div>
    </div>
    <div data-bs-theme="light" class="card border-1" style="height: 450px">
        <div class="card-header fw-bold"><?php echo e(__('Registered Staff')); ?></div>
        <div class="card-body card-data-table">
            <?php if($users->count() > 0): ?>
                <div class="table">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th class="">No</th>
                                <th class="">Name</th>
                                <th class="">Position</th>
                                <th class="">Email</th>
                                <th class="">Join at</th>
                                <th class="text-center">opt</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(++$key); ?></td>
                                    <td><?php echo e($user->name); ?></td>
                                    <?php if($user->position): ?>
                                        <td><?php echo e($user->position->name); ?></td>
                                    <?php else: ?>
                                        <td>None</td>
                                    <?php endif; ?>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->created_at); ?></td>
                                    <td>
                                        <div class="d-flex align-items-center justify-content-end gap-2">
                                            <form action="<?php echo e(route('index', "user-".$user->id)); ?>" method="post"
                                                class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit"
                                                    class="btn btn-danger btn-sm d-flex align-items-center gap-2"
                                                    onclick="return confirm('Delete <?php echo e($user->name); ?> from user database?')">
                                                    <i class="bx bx-trash-alt"></i> Remove
                                                </button>
                                            </form>
                                            <button type="button" data-bs-toggle="modal"
                                                data-bs-target="#addModalUser<?php echo e($user->id); ?>"
                                                class="btn btn-sm btn-primary text-white d-flex align-items-center gap-2">
                                                <i class='bx bx-edit'></i> Edit
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <div class="modal fade" id="addModalUser<?php echo e($user->id); ?>" tabindex="-1"
                                    aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h1 class="modal-title fs-5">Edit Position For <?php echo e($user->name); ?></h1>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <form action="<?php echo e(route('index', 'user-'.$user->id)); ?>"
                                                    method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PUT'); ?>
                                                    <div class="mb-3">
                                                        <label for="name">Staff Name</label>
                                                        <input type="text" name="name" id="name"
                                                            value="<?php echo e($user->name); ?>" class="form-control"
                                                            required readonly>
                                                        <label for="position_id">Choose Position</label>
                                                        <select name="position_id" id="position_id" class="form-control" required>
                                                            <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($position->id); ?>"><?php echo e($position->name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                    <button class="btn btn-primary px-4" type="submit">
                                                        Save Changes
                                                    </button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="mb-0 text-danger text-center">Belum ada Posisi Staff</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/baskoro/project/laravel-projects/vegasfinance/resources/views/management/employees.blade.php ENDPATH**/ ?>