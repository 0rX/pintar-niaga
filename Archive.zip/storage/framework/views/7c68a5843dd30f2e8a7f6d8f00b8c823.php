<?php $__env->startSection('content'); ?>

<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<div class="container" data-bs-theme="light">
    <div class="row justify-content-center">
        <div class="col-md-11">
            <div data-bs-theme="light" class="card border-1 mb-4" style="max-height: 400px;">
                <div class="card-header d-flex fw-bold">
                    <div class="me-auto">
                        <?php echo e($title); ?>

                    </div>
                    <div class="ms-auto">
                        <button type="button" data-bs-toggle="modal"
                            data-bs-target="#addAccModal"
                            class="btn btn-sm btn-primary text-white d-flex align-items-center gap-2">
                            <i class='bx bx-edit'></i> New
                        </button>
                    </div>
                </div>
                <div class="modal fade" id="addAccModal" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h1 class="modal-title fs-5">Create Category</h1>
                                <button type="button" class="btn btn-danger px-1 py-0 my-0" data-bs-dismiss="modal"
                                    aria-label="Close"><i class='bx bx-x fs-3 pt-1'></i></button>
                            </div>
                            <div class="modal-body">
                                <form action="<?php echo e(route('categories-index.store')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="mb-5">
                                        <label for="cp_index" class="ms-2">Company Index</label>
                                        <input type="text" value="<?php echo e($cp_index); ?>" name="cp_index" id="cp_index" class="form-control mb-3 fs-5" readonly>
                                        <label for="name" class="ms-2">Category Name</label>
                                        <input type="text" name="name" id="name" class="form-control mb-3 fs-5" required>
                                        <label for="description" class="ms-2">Description</label>
                                        <textarea name="description" id="description" class="form-control mb-3 fs-5" row="3" style="resize:none;"></textarea>
                                    </div>
                                    <div class="d-flex my-3 align-items-center justify-content-center gap-2">
                                        <button class="btn btn-primary" type="submit">
                                            Create
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-body card-data-table">
                    <?php if($categories->count() > 0): ?>
                        <?php
                            $cp_index += 1;
                        ?>
                        <div class="table">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th class="text-start" scope="col">No</th>
                                        <th class="text-start" scope="col">Category Name</th>
                                        <th class="text-center" scope="col">Items</th>
                                        <th class="text-start" scope="col">Description</th>
                                        <th class="text-end" scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e(++$key); ?></td>
                                            <?php
                                                $ct_index = $categories->pluck('name')->search($category->name) + 1;
                                            ?>
                                            <td style="max-width: 100px;">
                                                <a href="/manage/<?php echo e($cp_index); ?>/categories/<?php echo e($ct_index); ?>/">
                                                    <?php echo e($category->name); ?>

                                                </a>
                                            </td>
                                            <td class="text-center" style="max-width: 200px;"><?php echo e($category->products->count()); ?> items</td>
                                            <td class="text-start" style="max-width: 200px;"><?php echo e($category->description); ?></td>
                                            <td>
                                                <div class="d-flex align-items-center justify-content-end gap-2">
                                                    <button type="button" data-bs-toggle="modal"
                                                        data-bs-target="#addModal<?php echo e($category->category_id); ?>"
                                                        class="btn btn-sm btn-primary text-white d-flex align-items-center gap-2">
                                                        <i class='bx bx-edit'></i> Edit
                                                    </button>
                                                    
                                                    <form action="<?php echo e(route('categories-index.destroy', $category->category_id)); ?>" method="post"
                                                        class="d-inline">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit"
                                                            class="btn btn-danger btn-sm d-flex align-items-center gap-2 py-2"
                                                            onclick="return confirm('Delete <?php echo e($category->name); ?> ?')">
                                                            <i class='bx bxs-trash' ></i>
                                                        </button>
                                                    </form>
                                                    
                                                </div>
                                            </td>
                                        </tr>
                                        <div class="modal fade" id="addModal<?php echo e($category->category_id); ?>" tabindex="-1"
                                            aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h1 class="modal-title fs-5">Edit <?php echo e($category->name); ?></h1>
                                                        <button type="button" class="btn btn-danger px-1 py-0 my-0" data-bs-dismiss="modal"
                                                            aria-label="Close"><i class='bx bx-x fs-3 pt-1'></i></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form action="<?php echo e(route('categories-index.update', $category->category_id)); ?>"
                                                            method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('PUT'); ?>
                                                            <div class="mb-5">
                                                                <label for="name" class="ms-2">Category Name</label>
                                                                <input value="<?php echo e($category->name); ?>" type="text" name="name" id="name" class="form-control mb-3 fs-5" required>
                                                                <label for="description" class="ms-2">Description</label>
                                                                <textarea name="description" id="description" class="form-control mb-3 fs-5" row="3" style="resize:none;"><?php echo e($category->description); ?></textarea>
                                                            </div>
                                                            <button class="btn btn-primary px-4" type="submit">
                                                                Save Changes
                                                            </button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p class="mb-0 text-danger text-center">Nothing here</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/baskoro/project/laravel-projects/vegasfinance/resources/views/company/categories/index.blade.php ENDPATH**/ ?>