<?php $__env->startSection('content'); ?>

<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<div class="container" data-bs-theme="light">
    <div class="row justify-content-center">
        <div class="col-md-11">
            <div data-bs-theme="light" class="card border-1 mb-4" style="max-height: 400px;">
                <div class="card-header d-flex fw-bold">
                    <div class="me-auto">
                        New Transaction
                    </div>
                    <div class="ms-auto">
                        <?php echo e($title); ?>

                    </div>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('accounts-index.cashin')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="amount" class="form-label">Amount</label>
                            <input type="number" name="amount" id="amount" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea name="description" id="description" class="form-control" row="3" style="resize:none;"></textarea>
                        </div>
                        <button class="btn btn-primary px-4" type="submit">
                            Save
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/baskoro/project/laravel-projects/pintar-niaga/resources/views/company/accounts/cashin.blade.php ENDPATH**/ ?>