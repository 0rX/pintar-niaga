<?php $__env->startSection('content'); ?>

<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<div class="container" data-bs-theme="light">
    <div class="row justify-content-center">
        <div class="col-md-11">
            <div data-bs-theme="light" class="card border-1 mb-4" style="max-height: 800px;">
                <div class="card-body">
                    <div class="row justify-content-end px-4 fs-2">
                        <?php echo e($category->name); ?>

                    </div>
                    <div class="row my-1 px-1">
                        <div class="col-md-12 text-center border border-danger">
                            <div class="card-body card-data-table">
                                <div class="table">
                                    <table class="table table-stripped">
                                        <thead>
                                            <tr>
                                                <th class="text-start" scope="col">No</th>
                                                <th class="text-start" scope="col">Picture</th>
                                                <th class="text-start" scope="col">Product Name</th>
                                                <th class="text-start" scope="col">Stock</th>
                                                <th class="text-start" scope="col">Buy Price</th>
                                                <th class="text-start" scope="col">Sell Price</th>
                                                <th class="text-start" scope="col">Description</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e(++$key); ?></td>
                                                    <td style="max-width: 100px;"><?php echo e($product->image); ?></td>
                                                    <td style="max-width: 100px;"><?php echo e($product->name); ?></td>
                                                    <td style="max-width: 100px;"><?php echo e($product->stock); ?></td>
                                                    <td style="max-width: 100px;"><?php echo e($product->purchase_price); ?></td>
                                                    <td style="max-width: 100px;"><?php echo e($product->sale_price); ?></td>
                                                    <td style="max-width: 100px;"><?php echo e($product->description); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/baskoro/project/laravel-projects/vegasfinance/resources/views/company/categories/overview.blade.php ENDPATH**/ ?>