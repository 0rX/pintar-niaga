<?php $__env->startSection('content'); ?>

<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<div class="container" data-bs-theme="light">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div data-bs-theme="light" class="card border-1 mb-4" style="max-height: 850px;">
                <div class="card-header d-flex fw-bold">
                    <div class="me-auto">
                        New Transaction
                    </div>
                    <div class="ms-auto">
                        <?php echo e($title); ?>

                    </div>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('cashins-index.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="cp_index" class="ms-2 fw-bold">Company Index</label>
                            <input type="text" value="<?php echo e($cp_index); ?>" name="cp_index" id="cp_index" class="form-control mb-3 fs-5" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="title" class="form-label fw-bold">Title</label>
                            <input type="text" name="title" id="title" class="form-control fs-5" required>
                        </div>
                        <div class="mb-3">
                            <label for="account_id" class="form-label fw-bold">Select Account</label>
                            <select name="account_id" id="account_id" class="form-select me-2 fs-5" required>
                                <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($account->account_id); ?>"><?php echo e($account->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="total_amount" class="form-label fw-bold">Amount</label>
                            <input type="number" name="total_amount" id="total_amount" class="form-control fs-5" required>
                        </div>
                        <div class="mb-3">
                            <label for="description" class="form-label fw-bold">Description</label>
                            <textarea name="description" id="description" class="form-control fs-5" row="3" style="resize:none;"></textarea>
                        </div>
                        <button class="btn btn-primary px-4" type="submit">
                            Save
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/baskoro/project/laravel-projects/pintar-niaga/resources/views/company/cashins/index.blade.php ENDPATH**/ ?>